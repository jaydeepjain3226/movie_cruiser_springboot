package com.stackroute.java.service;

import java.util.List;

import com.stackroute.java.domain.Movie;

public interface MovieService {
	
	 public List<Movie> getAllMovie();
	 public Movie addMovie(Movie movie);
	 public Movie findByMovieId(int movieId);
	 public void deleteMovie(int movieId);
	 public void updateMovies(Movie movie);
	 

}
